import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler


def load_data():

    data = pd.read_csv("../data/stock_data.csv")

    data = data[['Close']]

    return data


def preprocess_data():

    data = load_data()

    scaler = MinMaxScaler(feature_range=(0,1))

    scaled_data = scaler.fit_transform(data)

    return scaled_data, scaler