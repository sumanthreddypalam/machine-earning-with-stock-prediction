import matplotlib.pyplot as plt
import pandas as pd
from predict import predict


def plot_prediction():

    data = pd.read_csv("../data/stock_data.csv")

    predicted_price = predict()

    plt.figure(figsize=(10,6))

    plt.plot(data['Close'], label="Actual Price")

    plt.scatter(
        len(data),
        predicted_price,
        color="red",
        label="Predicted Price"
    )

    plt.title("Stock Price Prediction")

    plt.xlabel("Time")

    plt.ylabel("Price")

    plt.legend()

    plt.show()


if __name__ == "__main__":
    plot_prediction()